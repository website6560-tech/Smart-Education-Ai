// Smart Education AI — Cloudflare Worker (ফ্রি)
// কাজ: API key সুরক্ষিত রাখা + Gemini-র streaming উত্তর সরাসরি অ্যাপে পাঠানো (কোনো buffering নেই = সবচেয়ে দ্রুত)

const LEVELS = {
  normal: "",
  simple: "Explain in very simple, easy language with a small everyday example.",
  academic: "Answer at an academic level (SSC/HSC/university) with correct terminology and structure.",
  admission: "Answer at admission-test level: precise, exam-oriented, include key formulas/points and shortcuts.",
};

function systemPrompt(level, lang) {
  const today = new Date().toISOString().slice(0, 10);
  const langRule =
    lang === "bn" ? "Always reply in Bangla." :
    lang === "en" ? "Always reply in English." :
    "Reply in the same language as the user's latest message (Bangla → Bangla, English → English).";
  return `You are Smart Education AI, a fast, friendly educational assistant for students (Bangladesh context: SSC/HSC/admission/madrasa/university). You help with general knowledge, science, math, ICT, Physics, Chemistry, Biology, Bangla, English and more. Today's date is ${today}.
Rules:
- ${langRule}
- Start directly with the answer. Be concise by default; give detail and steps when asked or when the problem needs it.
- Be accurate. If you are not sure, say so clearly (e.g. "আমি নিশ্চিত নই"). Never invent facts, numbers, quotes, or sources.
- Math: show step-by-step using plain Unicode math (x², √, ½, ×, ÷, ≤, ≥, π). Do NOT use LaTeX or $ signs.
- Use Markdown: short paragraphs, ## headings only for long answers, bullet/numbered lists, tables for comparisons, fenced code blocks with a language tag.
- Images: read text (OCR), solve the question shown, explain diagrams, graphs, screenshots and identify parts of diagrams.
- For medical, legal, financial or other high-stakes topics give careful general information and recommend a qualified professional.
- If the question is ambiguous, ask one short clarifying question.
- Do not mention who created you unless the user explicitly asks.
- If web search results are provided, base the answer on them and be honest if they are insufficient.
${LEVELS[level] || ""}`;
}

function toContents(messages) {
  return messages.map((m) => {
    const parts = [];
    if (m.image) parts.push({ inline_data: { mime_type: "image/jpeg", data: m.image } });
    parts.push({ text: m.text || " " });
    return { role: m.role === "user" ? "user" : "model", parts };
  });
}

async function callGemini(model, key, payload) {
  return fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse`,
    {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify(payload),
    }
  );
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const cors = {
      "access-control-allow-origin": "*",
      "access-control-allow-headers": "content-type, x-app-token",
      "access-control-allow-methods": "POST, GET, OPTIONS",
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (url.pathname === "/ping") return new Response("ok", { headers: cors });
    if (url.pathname !== "/chat" || request.method !== "POST")
      return new Response("Smart Education AI worker is running.", { headers: cors });

    if (env.APP_TOKEN && request.headers.get("x-app-token") !== env.APP_TOKEN)
      return new Response("unauthorized", { status: 401, headers: cors });
    if (!env.GEMINI_API_KEY) return new Response("server not configured", { status: 500, headers: cors });

    let body;
    try { body = await request.json(); } catch { return new Response("bad json", { status: 400, headers: cors }); }
    if (!Array.isArray(body.messages) || body.messages.length === 0)
      return new Response("no messages", { status: 400, headers: cors });

    const payload = {
      systemInstruction: { parts: [{ text: systemPrompt(body.level, body.lang) }] },
      contents: toContents(body.messages.slice(-20)),
      generationConfig: {
        temperature: 0.6,
        maxOutputTokens: 4096,
        thinkingConfig: { thinkingBudget: 0 }, // thinking বন্ধ = প্রথম token দ্রুত আসে
      },
    };
    if (body.search) payload.tools = [{ google_search: {} }];

    const model = env.MODEL || "gemini-2.5-flash";
    const fallback = env.FALLBACK_MODEL || "gemini-2.5-flash-lite";

    let up = await callGemini(model, env.GEMINI_API_KEY, payload);
    if (!up.ok && [429, 500, 503].includes(up.status) && fallback !== model) {
      up = await callGemini(fallback, env.GEMINI_API_KEY, payload); // ব্যস্ত থাকলে হালকা মডেলে
    }
    if (!up.ok) return new Response("upstream error", { status: up.status === 429 ? 429 : 502, headers: cors });

    return new Response(up.body, {
      status: 200,
      headers: { ...cors, "content-type": "text/event-stream", "cache-control": "no-cache, no-transform", "x-accel-buffering": "no" },
    });
  },
};
