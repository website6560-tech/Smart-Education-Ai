package com.smarteducation.ai

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColors = lightColorScheme(
    primary = Color(0xFF1F5FFF), onPrimary = Color.White,
    primaryContainer = Color(0xFFD9E4FF), onPrimaryContainer = Color(0xFF0B2A6B),
    secondary = Color(0xFF00A88F), onSecondary = Color.White,
    secondaryContainer = Color(0xFFD9E4FF), onSecondaryContainer = Color(0xFF0B2A6B),
    background = Color(0xFFF4F6FB), onBackground = Color(0xFF101828),
    surface = Color.White, onSurface = Color(0xFF101828),
    surfaceVariant = Color(0xFFE6EAF4), onSurfaceVariant = Color(0xFF3B4559),
    outline = Color(0xFF8A94A8), error = Color(0xFFD92D20),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7BA4FF), onPrimary = Color(0xFF07163A),
    primaryContainer = Color(0xFF28365A), onPrimaryContainer = Color(0xFFD9E4FF),
    secondary = Color(0xFF3DDCC0), onSecondary = Color(0xFF00382F),
    secondaryContainer = Color(0xFF28365A), onSecondaryContainer = Color(0xFFD9E4FF),
    background = Color(0xFF0D111B), onBackground = Color(0xFFE8ECF5),
    surface = Color(0xFF171D2B), onSurface = Color(0xFFE8ECF5),
    surfaceVariant = Color(0xFF232B3D), onSurfaceVariant = Color(0xFFB8C1D6),
    outline = Color(0xFF6B7690), error = Color(0xFFFF8A80),
)

@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val w = (view.context as Activity).window
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
