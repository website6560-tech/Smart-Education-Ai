package com.smarteducation.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File

object ImageUtil {
    /** ছবি ছোট করে (maxPx) JPEG হিসেবে সংরক্ষণ — আপলোড দ্রুত হয়, AI-ও দ্রুত পড়ে। */
    fun prepare(ctx: Context, uri: Uri, out: File, maxPx: Int): PendingImage? {
        return try {
            val cr = ctx.contentResolver
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, b) }
            if (b.outWidth <= 0 || b.outHeight <= 0) return null
            var s = 1
            while (maxOf(b.outWidth, b.outHeight) / (s * 2) >= maxPx) s *= 2
            val o = BitmapFactory.Options().apply { inSampleSize = s }
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return null
            val rot = cr.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                }
            } ?: 0f
            val scale = minOf(1f, maxPx.toFloat() / maxOf(bmp.width, bmp.height))
            if (scale < 1f || rot != 0f) {
                val m = Matrix().apply { postScale(scale, scale); postRotate(rot) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 82, bos)
            out.writeBytes(bos.toByteArray())
            PendingImage(out.absolutePath)
        } catch (e: Exception) { null }
    }

    /** UI-তে ছোট thumbnail দেখানোর জন্য (memory বাঁচায়) */
    fun decodeSampled(path: String, maxPx: Int): Bitmap? {
        return try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, b)
            var s = 1
            while (maxOf(b.outWidth, b.outHeight) / (s * 2) >= maxPx) s *= 2
            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
        } catch (e: Exception) { null }
    }
}
