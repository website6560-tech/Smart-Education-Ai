package com.smarteducation.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed interface Chunk {
    data class Text(val t: String) : Chunk
    data class Sources(val list: List<Src>) : Chunk
}

class ApiException(message: String) : Exception(message)

object Api {
    // একটি shared client: connection pool + HTTP/2 reuse = পরের request-এ TLS handshake লাগে না
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun endpoint(base: String, path: String) = base.trim().trimEnd('/') + path

    /** অ্যাপ খোলার সাথে সাথে connection আগেই গরম করে রাখে — প্রথম উত্তর আরও দ্রুত আসে। */
    fun warmUp(base: String) {
        if (base.isBlank()) return
        try {
            client.newCall(Request.Builder().url(endpoint(base, "/ping")).build()).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {}
                override fun onResponse(call: Call, response: Response) { response.close() }
            })
        } catch (_: Exception) {}
    }

    fun stream(base: String, token: String, body: String): Flow<Chunk> = callbackFlow {
        if (base.isBlank()) {
            close(ApiException("AI সার্ভার সেট করা নেই। সেটিংস → সার্ভার-এ Worker URL দিন।"))
            awaitClose { }
            return@callbackFlow
        }
        val call: Call = try {
            val rb = Request.Builder()
                .url(endpoint(base, "/chat"))
                .post(body.toRequestBody("application/json".toMediaType()))
                .header("Accept", "text/event-stream")
                .header("Accept-Encoding", "identity") // compression বন্ধ: streaming chunk আটকে থাকবে না
            if (token.isNotBlank()) rb.header("x-app-token", token)
            client.newCall(rb.build())
        } catch (e: IllegalArgumentException) {
            close(ApiException("Worker URL সঠিক নয়। সেটিংস পরীক্ষা করুন।"))
            awaitClose { }
            return@callbackFlow
        }

        val job = launch(Dispatchers.IO) {
            try {
                call.execute().use { resp ->
                    if (!resp.isSuccessful) {
                        throw ApiException(
                            when (resp.code) {
                                401, 403 -> "অ্যাক্সেস টোকেন সঠিক নয়। সেটিংস পরীক্ষা করুন।"
                                429 -> "এই মুহূর্তে অনেক অনুরোধ হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।"
                                400 -> "অনুরোধটি প্রক্রিয়া করা যায়নি। ছোট করে আবার চেষ্টা করুন।"
                                else -> "AI সার্ভার এখন পাওয়া যাচ্ছে না। পুনরায় চেষ্টা করুন।"
                            }
                        )
                    }
                    val src = resp.body!!.source()
                    val seen = LinkedHashMap<String, Src>()
                    while (true) {
                        val line = src.readUtf8Line() ?: break
                        if (!line.startsWith("data:")) continue
                        val data = line.substring(5).trim()
                        if (data.isEmpty() || data == "[DONE]") continue
                        val o = JSONObject(data)
                        val block = o.optJSONObject("promptFeedback")?.optString("blockReason", "") ?: ""
                        if (block.isNotEmpty()) throw ApiException("এই অনুরোধের উত্তর দেওয়া সম্ভব হচ্ছে না।")
                        val c = o.optJSONArray("candidates")?.optJSONObject(0) ?: continue
                        val parts = c.optJSONObject("content")?.optJSONArray("parts")
                        if (parts != null) {
                            for (i in 0 until parts.length()) {
                                val p = parts.getJSONObject(i)
                                if (p.optBoolean("thought")) continue
                                val t = p.optString("text", "")
                                if (t.isNotEmpty()) trySend(Chunk.Text(t))
                            }
                        }
                        val gc = c.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
                        if (gc != null) {
                            for (i in 0 until gc.length()) {
                                val w = gc.optJSONObject(i)?.optJSONObject("web") ?: continue
                                val u = w.optString("uri", "")
                                if (u.isNotEmpty()) seen.putIfAbsent(u, Src(w.optString("title", u), u))
                            }
                        }
                    }
                    if (seen.isNotEmpty()) trySend(Chunk.Sources(seen.values.toList()))
                }
                close()
            } catch (e: Throwable) {
                close(e)
            }
        }
        awaitClose { call.cancel(); job.cancel() }
    }.buffer(Channel.UNLIMITED)
}
