package com.smarteducation.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** চ্যাট ইতিহাস device-এর local storage-এ (JSON ফাইল)। প্রতি চ্যাট = একটি ফাইল, তাই লোড দ্রুত। */
class Repo(ctx: Context) {
    private val dir = File(ctx.filesDir, "chats").apply { mkdirs() }
    private val imgDir = File(ctx.filesDir, "img").apply { mkdirs() }
    private val indexFile = File(ctx.filesDir, "index.json")

    fun newImageFile() = File(imgDir, UUID.randomUUID().toString() + ".jpg")

    private fun atomicWrite(f: File, text: String) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(f)) { f.writeText(text); tmp.delete() }
    }

    fun loadIndex(): List<Meta> = try {
        val a = JSONArray(indexFile.readText())
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Meta(o.getString("id"), o.getString("title"), o.getLong("updated"))
        }.sortedByDescending { it.updated }
    } catch (e: Exception) { emptyList() }

    fun saveIndex(list: List<Meta>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("updated", it.updated)) }
        atomicWrite(indexFile, a.toString())
    }

    private fun msgToJson(m: Msg, keepImage: Boolean = true): JSONObject = JSONObject().apply {
        put("id", m.id); put("role", m.role); put("text", m.text)
        if (keepImage && m.imagePath != null) put("img", m.imagePath)
        if (m.error) put("err", true)
        if (m.sources.isNotEmpty()) put("src", JSONArray().apply {
            m.sources.forEach { put(JSONObject().put("t", it.title).put("u", it.url)) }
        })
    }

    private fun jsonToMsg(o: JSONObject, keepImage: Boolean = true): Msg {
        val srcs = ArrayList<Src>()
        o.optJSONArray("src")?.let { a ->
            for (i in 0 until a.length()) {
                val s = a.getJSONObject(i); srcs.add(Src(s.optString("t"), s.optString("u")))
            }
        }
        val img = if (keepImage) o.optString("img", "").ifEmpty { null } else null
        return Msg(o.getString("id"), o.getString("role"), o.optString("text"), img, srcs, o.optBoolean("err", false))
    }

    fun loadChat(id: String): List<Msg> = try {
        val a = JSONArray(File(dir, "$id.json").readText())
        (0 until a.length()).map { jsonToMsg(a.getJSONObject(it)) }
    } catch (e: Exception) { emptyList() }

    fun saveChat(id: String, msgs: List<Msg>) {
        val a = JSONArray(); msgs.forEach { a.put(msgToJson(it)) }
        atomicWrite(File(dir, "$id.json"), a.toString())
    }

    fun deleteChat(id: String) {
        loadChat(id).forEach { m -> m.imagePath?.let { File(it).delete() } }
        File(dir, "$id.json").delete()
    }

    /** পুরো ইতিহাসে টেক্সট খোঁজা (raw ফাইলে, parse ছাড়া — দ্রুত) */
    fun searchIds(q: String): Set<String> {
        val ql = q.lowercase()
        return dir.listFiles()?.filter { it.extension == "json" && runCatching { it.readText().lowercase().contains(ql) }.getOrDefault(false) }
            ?.map { it.nameWithoutExtension }?.toSet() ?: emptySet()
    }

    fun clearAll() {
        dir.listFiles()?.forEach { it.delete() }
        imgDir.listFiles()?.forEach { it.delete() }
        indexFile.delete()
    }

    fun exportJson(metas: List<Meta>): String {
        val arr = JSONArray()
        metas.forEach { m ->
            arr.put(JSONObject().put("id", m.id).put("title", m.title).put("updated", m.updated)
                .put("msgs", JSONArray().apply { loadChat(m.id).forEach { put(msgToJson(it, false)) } }))
        }
        return JSONObject().put("v", 1).put("chats", arr).toString()
    }

    fun importJson(text: String, existing: Set<String>): List<Meta> {
        val res = ArrayList<Meta>()
        val ok = Regex("^[A-Za-z0-9-]{8,64}$")
        val arr = JSONObject(text).getJSONArray("chats")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.getString("id")
            if (id in existing || !ok.matches(id)) continue
            val msgs = JSONArray()
            val src = o.getJSONArray("msgs")
            for (j in 0 until src.length()) msgs.put(msgToJson(jsonToMsg(src.getJSONObject(j), false), false))
            atomicWrite(File(dir, "$id.json"), msgs.toString())
            res.add(Meta(id, o.getString("title"), o.getLong("updated")))
        }
        return res
    }
}
