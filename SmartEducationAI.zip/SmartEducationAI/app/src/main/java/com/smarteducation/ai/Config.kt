package com.smarteducation.ai

object Config {
    /** Cloudflare Worker URL, যেমন: "https://smart-edu-ai.yourname.workers.dev"
     *  এখানে না দিলেও চলবে — অ্যাপের Settings → সার্ভার-এ পরে দেওয়া যাবে। */
    const val DEFAULT_WORKER_URL = ""

    /** Worker-এ APP_TOKEN সেট করলে একই মান এখানে/Settings-এ দিন (ঐচ্ছিক)। */
    const val DEFAULT_APP_TOKEN = ""
}
