package com.smarteducation.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

sealed interface Block
data class Para(val text: String) : Block
data class Head(val level: Int, val text: String) : Block
data class Bullet(val text: String, val indent: Int) : Block
data class Num(val n: String, val text: String, val indent: Int) : Block
data class Quote(val text: String) : Block
data class Code(val lang: String, val code: String) : Block
data class Table(val rows: List<List<String>>) : Block
object Rule : Block

private val headRe = Regex("^(#{1,4})\\s+(.*)$")
private val bulletRe = Regex("^(\\s*)[-*•+]\\s+(.*)$")
private val numRe = Regex("^(\\s*)(\\d+)[.)]\\s+(.*)$")
private val ruleRe = Regex("^(-{3,}|\\*{3,}|_{3,})$")
private val sepRe = Regex("^\\|?[\\s:|-]+\\|?$")

fun parseBlocks(src: String): List<Block> {
    val out = ArrayList<Block>()
    val lines = src.replace("\r", "").split("\n")
    val para = StringBuilder()
    fun flush() { if (para.isNotBlank()) out.add(Para(para.toString().trim())); para.clear() }
    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val t = line.trim()
        if (t.startsWith("```")) {
            flush()
            val lang = t.removePrefix("```").trim()
            val sb = StringBuilder(); i++
            while (i < lines.size && !lines[i].trim().startsWith("```")) { sb.append(lines[i]).append('\n'); i++ }
            out.add(Code(lang, sb.toString().trimEnd('\n')))
        } else if (t.isEmpty()) {
            flush()
        } else if (t.startsWith("|")) {
            flush()
            val rows = ArrayList<List<String>>()
            while (i < lines.size && lines[i].trim().startsWith("|")) {
                val r = lines[i].trim()
                if (!sepRe.matches(r)) rows.add(r.trim('|').split("|").map { it.trim() })
                i++
            }
            i--
            out.add(Table(rows))
        } else {
            val h = headRe.find(t)
            val b = bulletRe.find(line)
            val n = numRe.find(line)
            when {
                h != null -> { flush(); out.add(Head(h.groupValues[1].length, h.groupValues[2])) }
                ruleRe.matches(t) -> { flush(); out.add(Rule) }
                b != null -> { flush(); out.add(Bullet(b.groupValues[2], minOf(3, b.groupValues[1].length / 2))) }
                n != null -> { flush(); out.add(Num(n.groupValues[2] + ".", n.groupValues[3], minOf(3, n.groupValues[1].length / 2))) }
                t.startsWith(">") -> { flush(); out.add(Quote(t.removePrefix(">").trim())) }
                else -> para.append(t).append('\n')
            }
        }
        i++
    }
    flush()
    return out
}

// ---- গণিত: ভুল করে LaTeX এলে পড়ার উপযোগী Unicode-এ রূপান্তর ----
private val fracRe = Regex("\\\\d?frac\\{([^{}]*)\\}\\{([^{}]*)\\}")
private val sqrtRe = Regex("\\\\sqrt\\{([^{}]*)\\}")
private val textRe = Regex("\\\\text\\{([^{}]*)\\}")
private val mathRepl = listOf(
    "\\times" to "×", "\\div" to "÷", "\\cdot" to "·", "\\pm" to "±", "\\leq" to "≤", "\\geq" to "≥",
    "\\neq" to "≠", "\\approx" to "≈", "\\rightarrow" to "→", "\\to" to "→", "\\infty" to "∞",
    "\\pi" to "π", "\\theta" to "θ", "\\alpha" to "α", "\\beta" to "β", "\\gamma" to "γ", "\\lambda" to "λ",
    "\\mu" to "μ", "\\omega" to "ω", "\\Delta" to "Δ", "\\sigma" to "σ", "\\degree" to "°",
    "\\left" to "", "\\right" to "", "\\(" to "", "\\)" to "", "\\[" to "", "\\]" to "", "$$" to "",
)

fun prettyMath(s: String): String {
    if (!s.contains('\\') && !s.contains("$$")) return s
    var r = fracRe.replace(s) { "(${it.groupValues[1]})/(${it.groupValues[2]})" }
    r = sqrtRe.replace(r) { "√(${it.groupValues[1]})" }
    r = textRe.replace(r) { it.groupValues[1] }
    for ((a, b) in mathRepl) r = r.replace(a, b)
    return r
}

private fun inline(raw: String, codeBg: Color, link: Color): AnnotatedString {
    val s = prettyMath(raw)
    return buildAnnotatedString {
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '*' && s.startsWith("**", i)) {
                val e = s.indexOf("**", i + 2)
                if (e > i + 2) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(s.substring(i + 2, e)) }
                    i = e + 2; continue
                }
            }
            if (c == '`') {
                val e = s.indexOf('`', i + 1)
                if (e > i + 1) {
                    withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) { append(s.substring(i + 1, e)) }
                    i = e + 1; continue
                }
            }
            if (c == '*' && i + 1 < s.length && s[i + 1] != ' ' && s[i + 1] != '*' && (i == 0 || !s[i - 1].isLetterOrDigit())) {
                val e = s.indexOf('*', i + 1)
                if (e > i + 1 && s[e - 1] != ' ') {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(s.substring(i + 1, e)) }
                    i = e + 1; continue
                }
            }
            if (c == '[') {
                val mid = s.indexOf("](", i)
                val end = if (mid > 0) s.indexOf(')', mid) else -1
                if (mid > i + 1 && end > mid) {
                    val label = s.substring(i + 1, mid)
                    val url = s.substring(mid + 2, end)
                    if (url.startsWith("http") && !label.contains('\n')) {
                        pushStringAnnotation("URL", url)
                        withStyle(SpanStyle(color = link, textDecoration = TextDecoration.Underline)) { append(label) }
                        pop()
                        i = end + 1; continue
                    }
                }
            }
            append(c); i++
        }
    }
}

@Composable
private fun Rich(s: String, color: Color, size: TextUnit, modifier: Modifier = Modifier, weight: FontWeight? = null) {
    val uri = LocalUriHandler.current
    val codeBg = color.copy(alpha = 0.14f)
    val link = MaterialTheme.colorScheme.primary
    val a = remember(s, color, link) { inline(s, codeBg, link) }
    ClickableText(
        text = a,
        modifier = modifier,
        style = TextStyle(color = color, fontSize = size, fontWeight = weight, lineHeight = size * 1.45f),
        onClick = { off -> a.getStringAnnotations("URL", off, off).firstOrNull()?.let { runCatching { uri.openUri(it.item) } } },
    )
}

@Composable
fun MarkdownText(text: String, color: Color) {
    val blocks = remember(text) { parseBlocks(text) }
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        blocks.forEach { b ->
            when (b) {
                is Para -> Rich(b.text, color, 15.sp)
                is Head -> Rich(b.text, color, when (b.level) { 1 -> 20.sp; 2 -> 18.sp; else -> 16.sp }, weight = FontWeight.Bold)
                is Bullet -> Row(Modifier.padding(start = (b.indent * 14).dp)) {
                    Text("•", color = color, fontSize = 15.sp, modifier = Modifier.width(16.dp))
                    Rich(b.text, color, 15.sp)
                }
                is Num -> Row(Modifier.padding(start = (b.indent * 14).dp)) {
                    Text(b.n, color = color, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.widthIn(min = 24.dp))
                    Rich(b.text, color, 15.sp)
                }
                is Quote -> Row(Modifier.height(IntrinsicSize.Min)) {
                    Box(Modifier.width(3.dp).fillMaxHeight().background(MaterialTheme.colorScheme.primary))
                    Spacer(Modifier.width(8.dp))
                    Rich(b.text, color.copy(alpha = 0.85f), 15.sp)
                }
                is Code -> CodeBlock(b)
                is Table -> TableView(b, color)
                Rule -> HorizontalDivider(color = color.copy(alpha = 0.25f))
            }
        }
    }
}

@Composable
private fun CodeBlock(code: Code) {
    val clip = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { delay(1500); copied = false } }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF1B1F2B))) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF2A3042)).padding(start = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(code.lang.ifEmpty { "code" }, color = Color(0xFFAAB3C8), fontSize = 12.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { clip.setText(AnnotatedString(code.code)); copied = true }) {
                Text(if (copied) "✓ কপি হয়েছে" else "কপি", fontSize = 12.sp, color = Color(0xFF9DBBFF))
            }
        }
        Text(
            code.code,
            Modifier.horizontalScroll(rememberScrollState()).padding(10.dp),
            color = Color(0xFFE6EAF2), fontFamily = FontFamily.Monospace, fontSize = 13.sp,
        )
    }
}

@Composable
private fun TableView(t: Table, color: Color) {
    Column(Modifier.horizontalScroll(rememberScrollState())) {
        t.rows.forEachIndexed { r, row ->
            Row(Modifier.background(if (r == 0) color.copy(alpha = 0.12f) else Color.Transparent)) {
                row.forEach { cell ->
                    Text(
                        prettyMath(cell.replace("**", "")), color = color, fontSize = 14.sp,
                        fontWeight = if (r == 0) FontWeight.Bold else null,
                        modifier = Modifier.width(120.dp).padding(6.dp),
                    )
                }
            }
            HorizontalDivider(color = color.copy(alpha = 0.2f))
        }
    }
}
