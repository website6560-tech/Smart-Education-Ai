package com.smarteducation.ai

/** Creator প্রশ্ন ধরে নেটওয়ার্ক ছাড়াই সাথে সাথে উত্তর দেয় (তাই সবচেয়ে দ্রুত)। */
object CreatorQ {
    const val REPLY = "আমাকে তৈরি করেছেন মোঃ সাদিকুল ইসলাম।\nতিনি কুড়িগ্রাম আলিয়া কামিল মাদ্রাসায় পড়াশোনা করেন।"

    private const val VERB = "(বানিয়েছ|বানাইছ|বানাইস|বানাল|বানাই|তৈরি\\s*করেছ|তৈরি\\s*করছ|তৈরি\\s*করল|তৈরি\\s*করসে|ডেভেলপ|সৃষ্টি\\s*করেছ)"
    private val patterns = listOf(
        Regex("(তোমাকে|আপনাকে|তোমায়|আপনারে)\\s*কে\\s*" + VERB),
        Regex("কে\\s*(তোমাকে|আপনাকে|তোমায়|আপনারে)\\s*" + VERB),
        Regex("(তোমার|আপনার)\\s*(creator|ক্রিয়েটর|ক্রিয়েটার|স্রষ্টা|নির্মাতা|ডেভেলপার|developer|মেকার|প্রস্তুতকারক)", RegexOption.IGNORE_CASE),
        Regex("who\\s+(created|made|built|developed|designed|programmed)\\s+(you|this)", RegexOption.IGNORE_CASE),
        Regex("(your|ur)\\s+(creator|developer|maker)", RegexOption.IGNORE_CASE),
    )

    fun matches(t: String): Boolean = t.length <= 120 && patterns.any { it.containsMatchIn(t) }
}

private val searchWords = listOf(
    "আজ", "আজকের", "এখন", "বর্তমান", "সর্বশেষ", "সর্বশেষ", "নতুন", "খবর", "সংবাদ", "ফলাফল", "রেজাল্ট",
    "দাম", "রেট", "লাইভ", "সার্চ", "খুঁজে", "ওয়েব", "ওয়েবসাইট", "গতকাল", "এই সপ্তাহ", "এই বছর", "চলতি",
    "latest", "current", "currently", "today", "tonight", "news", "right now", "price", "score", "result",
    "weather", "search", "google", "update", "recent", "breaking", "http", "www.", "2025", "2026", "this week", "this year",
)

/** "Auto" মোডে শুধু current তথ্য লাগলেই web search — সাধারণ প্রশ্নে অযথা দেরি নয়। */
fun needsSearch(text: String): Boolean {
    val t = text.lowercase()
    return searchWords.any { t.contains(it) }
}
