package com.smarteducation.ai

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val crashFile = File(filesDir, "crash.txt")
        val oldHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { crashFile.writeText(Log.getStackTraceString(e)) } catch (_: Throwable) {}
            oldHandler?.uncaughtException(t, e)
        }
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val crash: String? = try { if (crashFile.exists()) crashFile.readText() else null } catch (_: Throwable) { null }
        if (crash != null) {
            setContent {
                CrashScreen(crash) {
                    crashFile.delete()
                    recreate()
                }
            }
            return
        }
        setContent {
            val vm: AppVM = viewModel()
            AppTheme(vm.settings.theme) { AppRoot(vm) }
        }
    }
}

@Composable
private fun CrashScreen(text: String, onRetry: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
        Text("অ্যাপ ক্র্যাশ করেছিল। এই লেখার স্ক্রিনশট পাঠান।", fontSize = 14.sp)
        Button(onClick = onRetry, modifier = Modifier.padding(vertical = 8.dp)) { Text("আবার চেষ্টা করুন") }
        SelectionContainer {
            Text(text.take(3500), fontSize = 10.sp, modifier = Modifier.verticalScroll(rememberScrollState()))
        }
    }
}
