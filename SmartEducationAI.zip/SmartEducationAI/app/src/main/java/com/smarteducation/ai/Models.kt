package com.smarteducation.ai

data class Src(val title: String, val url: String)

data class Msg(
    val id: String,
    val role: String, // "user" | "assistant"
    val text: String,
    val imagePath: String? = null,
    val sources: List<Src> = emptyList(),
    val error: Boolean = false,
)

data class Meta(val id: String, val title: String, val updated: Long)

data class PendingImage(val path: String)
