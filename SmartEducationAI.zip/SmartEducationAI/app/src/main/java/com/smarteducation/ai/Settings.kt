package com.smarteducation.ai

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var theme by mutableIntStateOf(p.getInt("theme", 0)); private set          // 0 system, 1 light, 2 dark
    var webSearch by mutableIntStateOf(p.getInt("search", 1)); private set     // 0 off, 1 auto, 2 always
    var level by mutableIntStateOf(p.getInt("level", 0)); private set          // 0 normal, 1 simple, 2 academic, 3 admission
    var lang by mutableIntStateOf(p.getInt("lang", 0)); private set            // 0 auto, 1 bn, 2 en
    var imageQuality by mutableIntStateOf(p.getInt("imgq", 1)); private set    // 0 fast, 1 balanced, 2 high
    var newChatOnLaunch by mutableStateOf(p.getBoolean("newOnLaunch", false)); private set
    var workerUrl by mutableStateOf(p.getString("worker", Config.DEFAULT_WORKER_URL) ?: ""); private set
    var token by mutableStateOf(p.getString("token", Config.DEFAULT_APP_TOKEN) ?: ""); private set

    @JvmName("updateTheme") fun setTheme(v: Int) { theme = v; p.edit().putInt("theme", v).apply() }
    @JvmName("updateWebSearch") fun setWebSearch(v: Int) { webSearch = v; p.edit().putInt("search", v).apply() }
    @JvmName("updateLevel") fun setLevel(v: Int) { level = v; p.edit().putInt("level", v).apply() }
    @JvmName("updateLang") fun setLang(v: Int) { lang = v; p.edit().putInt("lang", v).apply() }
    @JvmName("updateImageQuality") fun setImageQuality(v: Int) { imageQuality = v; p.edit().putInt("imgq", v).apply() }
    @JvmName("updateNewChatOnLaunch") fun setNewChatOnLaunch(v: Boolean) { newChatOnLaunch = v; p.edit().putBoolean("newOnLaunch", v).apply() }
    @JvmName("updateWorkerUrl") fun setWorkerUrl(v: String) { workerUrl = v; p.edit().putString("worker", v).apply() }
    @JvmName("updateToken") fun setToken(v: String) { token = v; p.edit().putString("token", v).apply() }
}
