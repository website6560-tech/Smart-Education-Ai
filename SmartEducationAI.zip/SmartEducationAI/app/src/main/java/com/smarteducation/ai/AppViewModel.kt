package com.smarteducation.ai

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.os.SystemClock
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID

private const val NO_NET = "Internet connection নেই। সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।"

@OptIn(ExperimentalCoroutinesApi::class)
class AppVM(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext
    private val repo = Repo(ctx)
    val settings = Settings(ctx)
    private val disk = Dispatchers.IO.limitedParallelism(1)

    val messages = mutableStateListOf<Msg>()
    val chats = mutableStateListOf<Meta>()
    var chatId by mutableStateOf<String?>(null); private set
    var busy by mutableStateOf(false); private set
    var slow by mutableStateOf(false); private set
    var online by mutableStateOf(true); private set
    var pending by mutableStateOf<PendingImage?>(null); private set
    var pendingLoading by mutableStateOf(false); private set
    var notice by mutableStateOf<String?>(null); private set
    var backupMsg by mutableStateOf<String?>(null); private set
    var tab by mutableIntStateOf(0)
    var historyQuery by mutableStateOf(""); private set
    var searchHits by mutableStateOf<Set<String>?>(null); private set

    private var job: Job? = null
    private var searchJob: Job? = null
    private val cm = ctx.getSystemService(ConnectivityManager::class.java)
    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { online = true }
        override fun onLost(network: Network) { online = false }
    }

    init {
        online = cm?.activeNetwork != null
        runCatching { cm?.registerDefaultNetworkCallback(netCb) }
        Api.warmUp(settings.workerUrl)
        viewModelScope.launch {
            val idx = withContext(disk) { repo.loadIndex() }
            chats.clear(); chats.addAll(idx)
            if (!settings.newChatOnLaunch && idx.isNotEmpty() && chatId == null && messages.isEmpty()) {
                openChat(idx.first().id, goChat = false)
            }
        }
    }

    override fun onCleared() {
        runCatching { cm?.unregisterNetworkCallback(netCb) }
    }

    fun warmUp() = Api.warmUp(settings.workerUrl)

    private fun newId() = UUID.randomUUID().toString()

    // ---------- চ্যাট নেভিগেশন ----------

    private fun stopThen(block: () -> Unit) {
        val j = job
        if (j == null || !j.isActive) { block(); return }
        viewModelScope.launch { j.cancelAndJoin(); block() }
    }

    fun newChat() = stopThen {
        chatId = null; messages.clear(); discardPending(); notice = null; tab = 0
    }

    fun openChat(id: String, goChat: Boolean = true) = stopThen {
        chatId = id; messages.clear(); discardPending(); notice = null
        if (goChat) tab = 0
        viewModelScope.launch {
            val m = withContext(disk) { repo.loadChat(id) }
            if (chatId == id) { messages.clear(); messages.addAll(m) }
        }
    }

    fun deleteChat(id: String) {
        if (chatId == id) newChat()
        chats.removeAll { it.id == id }
        val idx = chats.toList()
        viewModelScope.launch(disk) { repo.deleteChat(id); repo.saveIndex(idx) }
    }

    fun rename(id: String, title: String) {
        val t = title.trim().ifEmpty { return }
        val i = chats.indexOfFirst { it.id == id }
        if (i < 0) return
        chats[i] = chats[i].copy(title = t.take(60))
        val idx = chats.toList()
        viewModelScope.launch(disk) { repo.saveIndex(idx) }
    }

    fun clearAll() = stopThen {
        chatId = null; messages.clear(); chats.clear(); discardPending(); notice = null
        viewModelScope.launch(disk) { repo.clearAll() }
    }

    fun onHistoryQuery(q: String) {
        historyQuery = q
        searchJob?.cancel()
        if (q.isBlank()) { searchHits = null; return }
        searchJob = viewModelScope.launch {
            delay(200)
            searchHits = withContext(disk) { repo.searchIds(q.trim()) }
        }
    }

    // ---------- ছবি ----------

    fun pickImage(uri: Uri) {
        notice = null
        viewModelScope.launch {
            pendingLoading = true
            val maxPx = when (settings.imageQuality) { 0 -> 768; 2 -> 1600; else -> 1024 }
            val p = withContext(Dispatchers.IO) { ImageUtil.prepare(ctx, uri, repo.newImageFile(), maxPx) }
            pendingLoading = false
            if (p == null) notice = "ছবিটি লোড করা যায়নি। আবার চেষ্টা করুন।"
            else { discardPending(); pending = p }
        }
    }

    fun discardPending() {
        pending?.let { File(it.path).delete() }
        pending = null
    }

    // ---------- পাঠানো ----------

    fun send(raw: String) {
        val t = raw.trim()
        val img = pending
        if (busy || pendingLoading || (t.isEmpty() && img == null)) return
        notice = null
        if (chatId == null) chatId = newId()
        messages.add(Msg(newId(), "user", t, imagePath = img?.path))
        pending = null
        if (img == null && CreatorQ.matches(t)) {
            messages.add(Msg(newId(), "assistant", CreatorQ.REPLY)) // নেটওয়ার্ক ছাড়াই তাৎক্ষণিক
            save(); return
        }
        save()
        generate()
    }

    fun stop() { job?.cancel() }

    fun regenerate() {
        if (busy) return
        val last = messages.lastOrNull() ?: return
        if (last.role == "assistant") messages.removeAt(messages.lastIndex)
        val u = messages.lastOrNull() ?: return
        if (u.role != "user") return
        if (u.imagePath == null && CreatorQ.matches(u.text)) {
            messages.add(Msg(newId(), "assistant", CreatorQ.REPLY)); save(); return
        }
        generate()
    }

    private fun buildBody(snapshot: List<Msg>, search: Boolean): String {
        val arr = JSONArray()
        val lastImg = snapshot.indexOfLast { it.role == "user" && it.imagePath != null }
        snapshot.forEachIndexed { i, m ->
            val text = if (m.text.isBlank() && m.imagePath != null) "এই ছবিটি বিশ্লেষণ করে ব্যাখ্যা করো।" else m.text
            val o = JSONObject().put("role", m.role).put("text", text)
            if (i == lastImg) {
                val bytes = runCatching { File(m.imagePath!!).readBytes() }.getOrNull()
                if (bytes != null) o.put("image", Base64.encodeToString(bytes, Base64.NO_WRAP))
            }
            arr.put(o)
        }
        return JSONObject().put("messages", arr).put("search", search)
            .put("level", arrayOf("normal", "simple", "academic", "admission")[settings.level])
            .put("lang", arrayOf("auto", "bn", "en")[settings.lang]).toString()
    }

    private fun update(id: String, text: String, srcs: List<Src>, err: Boolean) {
        val i = messages.indexOfLast { it.id == id }
        if (i >= 0) messages[i] = messages[i].copy(text = text, sources = srcs, error = err)
    }

    private fun generate() {
        val snapshot = messages.filter { !it.error && (it.text.isNotBlank() || it.imagePath != null) }
            .takeLast(16).dropWhile { it.role != "user" }
        val lastUser = snapshot.lastOrNull { it.role == "user" } ?: return
        val search = lastUser.imagePath == null && when (settings.webSearch) {
            2 -> true
            1 -> needsSearch(lastUser.text)
            else -> false
        }
        val aiId = newId()
        messages.add(Msg(aiId, "assistant", ""))
        busy = true; slow = false

        job = viewModelScope.launch {
            val slowJob = launch { delay(4000); slow = true }
            val sb = StringBuilder()
            var srcs: List<Src> = emptyList()
            var err: String? = null
            var lastUi = 0L
            try {
                if (!online) throw ApiException(NO_NET)
                val body = withContext(Dispatchers.IO) { buildBody(snapshot, search) }
                var attempt = 0
                while (true) {
                    try {
                        Api.stream(settings.workerUrl, settings.token, body).collect { ch ->
                            when (ch) {
                                is Chunk.Text -> {
                                    if (sb.isEmpty()) slowJob.cancel()
                                    sb.append(ch.t)
                                    val now = SystemClock.uptimeMillis()
                                    if (now - lastUi >= 45) { // UI throttle: লম্বা উত্তরেও lag হয় না
                                        lastUi = now
                                        update(aiId, sb.toString(), srcs, false)
                                    }
                                }
                                is Chunk.Sources -> srcs = ch.list
                            }
                        }
                        break
                    } catch (e: IOException) {
                        // শুরুর আগেই connection ফেল করলে একবার নিঃশব্দে আবার চেষ্টা
                        if (sb.isEmpty() && attempt == 0 && isActive) { attempt++; delay(350) } else throw e
                    }
                }
                if (sb.isEmpty()) err = "AI কোনো উত্তর দেয়নি। আবার চেষ্টা করুন।"
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiException) {
                err = e.message
            } catch (e: IOException) {
                err = if (!online) NO_NET else "সংযোগে সমস্যা হয়েছে। ইন্টারনেট পরীক্ষা করে আবার চেষ্টা করুন।"
            } catch (e: Exception) {
                err = "অপ্রত্যাশিত সমস্যা হয়েছে। আবার চেষ্টা করুন।"
            } finally {
                slowJob.cancel(); slow = false; busy = false
                val text = sb.toString()
                val i = messages.indexOfLast { it.id == aiId }
                if (i >= 0) {
                    if (text.isEmpty() && err == null) messages.removeAt(i) // থামানো হয়েছে, কিছু আসেনি
                    else messages[i] = messages[i].copy(
                        text = if (text.isEmpty()) err.orEmpty() else if (err != null) text + "\n\n⚠️ " + err else text,
                        sources = srcs, error = err != null
                    )
                }
                save()
            }
        }
    }

    // ---------- সংরক্ষণ ----------

    private fun save() {
        val id = chatId ?: return
        val snap = messages.toList()
        if (snap.isEmpty()) return
        val title = chats.firstOrNull { it.id == id }?.title ?: run {
            val first = snap.firstOrNull { it.role == "user" }
            val t = first?.text?.trim()?.lines()?.firstOrNull()?.take(40).orEmpty()
            if (t.isNotEmpty()) t else if (first?.imagePath != null) "ছবি বিশ্লেষণ" else "নতুন চ্যাট"
        }
        chats.removeAll { it.id == id }
        chats.add(0, Meta(id, title, System.currentTimeMillis()))
        val idx = chats.toList()
        viewModelScope.launch(disk) { repo.saveChat(id, snap); repo.saveIndex(idx) }
    }

    // ---------- ব্যাকআপ ----------

    fun exportTo(uri: Uri) {
        val metas = chats.toList()
        viewModelScope.launch {
            val ok = withContext(disk) {
                runCatching {
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(repo.exportJson(metas).toByteArray()) } != null
                }.getOrDefault(false)
            }
            backupMsg = if (ok) "ব্যাকআপ সংরক্ষিত হয়েছে ✓ (${metas.size}টি চ্যাট)" else "ব্যাকআপ করা যায়নি।"
        }
    }

    fun importFrom(uri: Uri) {
        val existing = chats.map { it.id }.toSet()
        viewModelScope.launch {
            val added = withContext(disk) {
                runCatching {
                    val text = ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } ?: ""
                    repo.importJson(text, existing)
                }.getOrNull()
            }
            if (added == null) backupMsg = "ফাইলটি পড়া যায়নি।"
            else {
                chats.addAll(added); chats.sortByDescending { it.updated }
                val idx = chats.toList()
                withContext(disk) { repo.saveIndex(idx) }
                backupMsg = "${added.size}টি চ্যাট ইমপোর্ট হয়েছে ✓"
            }
        }
    }
}
