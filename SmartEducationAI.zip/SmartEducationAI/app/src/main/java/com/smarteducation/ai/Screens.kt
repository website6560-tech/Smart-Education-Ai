@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.smarteducation.ai

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ======================= ROOT =======================

@Composable
fun AppRoot(vm: AppVM) {
    BackHandler(enabled = vm.tab != 0) { vm.tab = 0 }
    val imeVisible = WindowInsets.isImeVisible
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()
    ) {
        Box(Modifier.weight(1f).imePadding()) {
            when (vm.tab) {
                0 -> ChatScreen(vm)
                1 -> HistoryScreen(vm)
                2 -> SettingsScreen(vm)
                else -> AboutScreen()
            }
        }
        if (!imeVisible) {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                listOf("💬" to "চ্যাট", "🕘" to "ইতিহাস", "⚙️" to "সেটিংস", "ℹ️" to "পরিচিতি")
                    .forEachIndexed { i, (ic, label) ->
                        NavigationBarItem(
                            selected = vm.tab == i,
                            onClick = { vm.tab = i },
                            icon = { Text(ic, fontSize = 18.sp) },
                            label = { Text(label, fontSize = 11.sp) },
                        )
                    }
            }
        }
    }
}

// ======================= CHAT =======================

@Composable
fun ChatScreen(vm: AppVM) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    Box(Modifier.fillMaxSize()) {
        // ব্যাকগ্রাউন্ড ছবি (১০৮০px WebP, ~২৮KB) + পড়ার সুবিধার জন্য overlay
        Image(
            painterResource(R.drawable.chat_bg), null,
            Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
        )
        Box(Modifier.fillMaxSize().background(if (dark) Color.Black.copy(alpha = 0.66f) else Color.White.copy(alpha = 0.72f)))

        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface.copy(alpha = 0.93f))
                    .padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("🎓 Smart Education AI", fontWeight = FontWeight.Bold, fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.newChat() }) { Text("＋ নতুন চ্যাট", fontSize = 13.sp) }
            }
            if (!vm.online) {
                Text(
                    "⚠️ Internet connection নেই", Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.error)
                        .padding(6.dp), color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center,
                )
            }
            Box(Modifier.weight(1f)) {
                if (vm.messages.isEmpty()) EmptyState(vm) else MessageList(vm)
            }
            InputBar(vm)
        }
    }
}

@Composable
private fun EmptyState(vm: AppVM) {
    val onBg = if (MaterialTheme.colorScheme.background.luminance() < 0.5f) Color.White else Color(0xFF101828)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        Text("🎓", fontSize = 44.sp)
        Text("Smart Education AI", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = onBg)
        Text("যেকোনো প্রশ্ন বাংলা বা English-এ লিখুন, অথবা ছবি তুলে জিজ্ঞেস করুন।",
            color = onBg.copy(alpha = 0.85f), textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
        listOf(
            "পিথাগোরাসের উপপাদ্য সহজ ভাষায় বুঝিয়ে দাও",
            "x² − 5x + 6 = 0 ধাপে ধাপে সমাধান করো",
            "Explain Newton's laws of motion with examples",
            "সালোকসংশ্লেষণ admission level-এ ব্যাখ্যা করো",
        ).forEach { q ->
            Text(
                q, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp,
                modifier = Modifier.padding(vertical = 4.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))
                    .clickable { vm.send(q) }.padding(14.dp),
            )
        }
    }
}

@Composable
private fun MessageList(vm: AppVM) {
    val msgs = vm.messages
    val state = rememberLazyListState()
    // নতুন message এলে নিচে যাও
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) state.scrollToItem(0) }
    // reverseLayout: সর্বশেষ message নিচে থাকে, streaming-এ লেখা নিজে থেকেই নিচে অনুসরণ করে
    LazyColumn(
        state = state, reverseLayout = true,
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        items(count = msgs.size, key = { msgs.getOrNull(msgs.lastIndex - it)?.id ?: it }) { idx ->
            val m = msgs.getOrNull(msgs.lastIndex - idx)
            if (m != null) {
                if (m.role == "user") UserBubble(m) else AssistantBubble(vm, m, isLast = idx == 0)
            }
        }
    }
}

@Composable
fun FileImage(path: String, modifier: Modifier, maxPx: Int, scale: ContentScale = ContentScale.Fit) {
    val state = produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { ImageUtil.decodeSampled(path, maxPx)?.asImageBitmap() }
    }
    state.value?.let { Image(it, null, modifier, contentScale = scale) }
}

@Composable
private fun UserBubble(m: Msg) {
    Row(Modifier.fillMaxWidth().padding(start = 48.dp), horizontalArrangement = Arrangement.End) {
        Column(
            Modifier.weight(1f, fill = false)
                .clip(RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp))
                .background(MaterialTheme.colorScheme.primary).padding(10.dp)
        ) {
            m.imagePath?.let {
                FileImage(it, Modifier.fillMaxWidth().heightIn(max = 220.dp).clip(RoundedCornerShape(12.dp)), 600)
                if (m.text.isNotEmpty()) Spacer(Modifier.height(6.dp))
            }
            if (m.text.isNotEmpty()) Text(m.text, color = MaterialTheme.colorScheme.onPrimary, fontSize = 15.sp)
        }
    }
}

@Composable
private fun TypingDots(slow: Boolean) {
    val t = rememberInfiniteTransition(label = "dots")
    val a by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "a")
    Column {
        Text("● ● ●", color = MaterialTheme.colorScheme.primary.copy(alpha = a), fontSize = 14.sp)
        if (slow) Text("সংযোগ ধীর, একটু অপেক্ষা করুন…", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun AssistantBubble(vm: AppVM, m: Msg, isLast: Boolean) {
    val clip = LocalClipboardManager.current
    val uri = LocalUriHandler.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) { if (copied) { delay(1500); copied = false } }
    val surface = MaterialTheme.colorScheme.surface

    Row(Modifier.fillMaxWidth().padding(end = 12.dp)) {
        Column(Modifier.weight(1f, fill = false)) {
            Box(
                Modifier.clip(RoundedCornerShape(4.dp, 18.dp, 18.dp, 18.dp))
                    .background(surface.copy(alpha = 0.94f)).padding(12.dp)
            ) {
                if (m.text.isEmpty()) TypingDots(vm.slow)
                else MarkdownText(m.text, MaterialTheme.colorScheme.onSurface)
            }
            if (m.sources.isNotEmpty()) {
                Column(
                    Modifier.padding(top = 6.dp).clip(RoundedCornerShape(12.dp))
                        .background(surface.copy(alpha = 0.9f)).padding(8.dp)
                ) {
                    Text("সূত্র:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    m.sources.take(5).forEach { s ->
                        Text("🔗 " + s.title, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1,
                            modifier = Modifier.padding(top = 3.dp).clickable { runCatching { uri.openUri(s.url) } })
                    }
                }
            }
            if (m.text.isNotEmpty() && !(vm.busy && isLast)) {
                Row(
                    Modifier.padding(top = 4.dp).clip(RoundedCornerShape(14.dp)).background(surface.copy(alpha = 0.85f)),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(onClick = { clip.setText(AnnotatedString(m.text)); copied = true }) {
                        Text(if (copied) "✓ কপি হয়েছে" else "📋 কপি", fontSize = 12.sp)
                    }
                    if (isLast) TextButton(onClick = { vm.regenerate() }) {
                        Text(if (m.error) "🔄 আবার চেষ্টা করুন" else "🔄 আবার তৈরি করো", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun InputBar(vm: AppVM) {
    var text by rememberSaveable { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.pickImage(uri)
    }
    val canSend = (text.isNotBlank() || vm.pending != null) && !vm.pendingLoading
    Column(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)).padding(8.dp)
    ) {
        if (vm.pendingLoading) Text("ছবি প্রস্তুত হচ্ছে…", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        vm.pending?.let { p ->
            Box(Modifier.padding(bottom = 6.dp).size(72.dp)) {
                FileImage(p.path, Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)), 200, ContentScale.Crop)
                Text("✕", color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.TopEnd).clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.65f)).clickable { vm.discardPending() }.padding(5.dp))
            }
        }
        vm.notice?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp)) }
        Row(verticalAlignment = Alignment.Bottom) {
            IconButton(onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }) { Text("📷", fontSize = 22.sp) }
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("প্রশ্ন লিখুন…") },
                maxLines = 6, shape = RoundedCornerShape(24.dp),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
            )
            Spacer(Modifier.width(6.dp))
            if (vm.busy) {
                FilledIconButton(onClick = { vm.stop() }) { Text("■", fontSize = 16.sp) }
            } else {
                FilledIconButton(onClick = { vm.send(text); text = "" }, enabled = canSend) { Text("➤", fontSize = 16.sp) }
            }
        }
    }
}

// ======================= HISTORY =======================

private val dateFmt = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault())

@Composable
fun HistoryScreen(vm: AppVM) {
    var renameTarget by remember { mutableStateOf<Meta?>(null) }
    var deleteTarget by remember { mutableStateOf<Meta?>(null) }
    val q = vm.historyQuery.trim().lowercase()
    val hits = vm.searchHits
    val list = if (q.isEmpty()) vm.chats.toList()
    else vm.chats.filter { it.title.lowercase().contains(q) || hits?.contains(it.id) == true }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("চ্যাট ইতিহাস", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            FilledTonalButton(onClick = { vm.newChat() }) { Text("＋ নতুন চ্যাট") }
        }
        OutlinedTextField(
            value = vm.historyQuery, onValueChange = { vm.onHistoryQuery(it) },
            modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(24.dp),
            placeholder = { Text("🔍 ইতিহাসে খুঁজুন…") },
        )
        Spacer(Modifier.height(8.dp))
        if (list.isEmpty()) {
            Text(if (q.isEmpty()) "এখনো কোনো চ্যাট নেই।" else "কিছু পাওয়া যায়নি।",
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(list, key = { it.id }) { meta ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surface).padding(start = 14.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f).clickable { vm.openChat(meta.id) }.padding(vertical = 8.dp)) {
                        Text(meta.title, maxLines = 1, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(dateFmt.format(Date(meta.updated)), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { renameTarget = meta }) { Text("✏️") }
                    IconButton(onClick = { deleteTarget = meta }) { Text("🗑️") }
                }
            }
        }
    }

    renameTarget?.let { m ->
        var t by remember(m.id) { mutableStateOf(m.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("নাম পরিবর্তন") },
            text = { OutlinedTextField(value = t, onValueChange = { t = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.rename(m.id, t); renameTarget = null }) { Text("সংরক্ষণ") } },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("বাতিল") } },
        )
    }
    deleteTarget?.let { m ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("চ্যাট মুছবেন?") },
            text = { Text("\"${m.title}\" স্থায়ীভাবে মুছে যাবে।") },
            confirmButton = { TextButton(onClick = { vm.deleteChat(m.id); deleteTarget = null }) { Text("মুছুন", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("বাতিল") } },
        )
    }
}

// ======================= SETTINGS =======================

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        content()
    }
}

@Composable
private fun Choice(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, o ->
            FilterChip(selected = i == selected, onClick = { onSelect(i) }, label = { Text(o) })
        }
    }
}

@Composable
private fun Hint(t: String) = Text(t, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
fun SettingsScreen(vm: AppVM) {
    val s = vm.settings
    var confirmClear by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf(s.workerUrl) }
    var token by remember { mutableStateOf(s.token) }
    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) vm.exportTo(u)
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) vm.importFrom(u)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("সেটিংস", fontSize = 20.sp, fontWeight = FontWeight.Bold)

        Section("থিম") {
            Choice(listOf("সিস্টেম", "Light", "Dark"), s.theme) { s.setTheme(it) }
        }
        Section("ভাষা (AI-এর উত্তর)") {
            Choice(listOf("অটো (প্রশ্নের ভাষা)", "বাংলা", "English"), s.lang) { s.setLang(it) }
        }
        Section("উত্তরের ধরন") {
            Choice(listOf("সাধারণ", "সহজ ভাষায়", "Academic", "Admission"), s.level) { s.setLevel(it) }
        }
        Section("Web search") {
            Choice(listOf("বন্ধ", "অটো", "সবসময়"), s.webSearch) { s.setWebSearch(it) }
            Hint("অটো: শুধু চলতি/সর্বশেষ তথ্য দরকার হলে search করে (দ্রুততার জন্য সুপারিশকৃত)। সবসময়: প্রতি প্রশ্নে search — একটু ধীর।")
        }
        Section("ছবি বিশ্লেষণ / গতি") {
            Choice(listOf("দ্রুত", "ব্যালান্সড", "উচ্চ মান"), s.imageQuality) { s.setImageQuality(it) }
            Hint("দ্রুত = ছবি ছোট করে পাঠায় (আপলোড ও উত্তর দ্রুত)। ছোট লেখা/জটিল ডায়াগ্রামে 'উচ্চ মান' বেছে নিন।")
        }
        Section("নতুন চ্যাট") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("অ্যাপ খুললে নতুন চ্যাট শুরু", Modifier.weight(1f))
                Switch(checked = s.newChatOnLaunch, onCheckedChange = { s.setNewChatOnLaunch(it) })
            }
        }
        Section("সার্ভার (AI সংযোগ)") {
            OutlinedTextField(
                value = url, onValueChange = { url = it; s.setWorkerUrl(it.trim()) },
                label = { Text("Worker URL") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("https://....workers.dev") },
            )
            OutlinedTextField(
                value = token, onValueChange = { token = it; s.setToken(it.trim()) },
                label = { Text("App token (ঐচ্ছিক)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            TextButton(onClick = { vm.warmUp() }) { Text("🔌 সংযোগ গরম করুন") }
            Hint("API key অ্যাপে থাকে না; সব key আপনার Worker সার্ভারে সুরক্ষিত।")
        }
        Section("ডেটা ও প্রাইভেসি") {
            Hint("চ্যাট ইতিহাস শুধু আপনার ফোনেই থাকে। প্রশ্ন (ও ছবি) উত্তর তৈরির জন্য আপনার AI সার্ভারে HTTPS-এ যায়। ব্যক্তিগত/সংবেদনশীল তথ্য পাঠাবেন না।")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { exportL.launch("smart-education-ai-backup.json") }) { Text("☁️ ব্যাকআপ") }
                OutlinedButton(onClick = { importL.launch(arrayOf("application/json", "text/plain", "*/*")) }) { Text("📥 রিস্টোর") }
            }
            vm.backupMsg?.let { Hint(it) }
            Hint("ব্যাকআপ ফাইল Google Drive-এ সংরক্ষণ করা যায় (ছবি বাদে শুধু লেখা)।")
            Button(
                onClick = { confirmClear = true },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = Color.White),
            ) { Text("🗑️ সব চ্যাট ইতিহাস মুছুন") }
        }
        Section("Creator") {
            Text(CreatorQ.REPLY, fontSize = 14.sp)
        }
        Spacer(Modifier.height(8.dp))
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("সব ইতিহাস মুছবেন?") },
            text = { Text("সব চ্যাট স্থায়ীভাবে মুছে যাবে।") },
            confirmButton = { TextButton(onClick = { vm.clearAll(); confirmClear = false }) { Text("মুছুন", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("বাতিল") } },
        )
    }
}

// ======================= ABOUT =======================

@Composable
fun AboutScreen() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Spacer(Modifier.height(12.dp))
        Text("🎓", fontSize = 56.sp)
        Text("Smart Education AI", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Version 1.0", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Text("Fast, Smart, Educational and Reliable AI Assistant", textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        Section("বৈশিষ্ট্য") {
            listOf(
                "⚡ Streaming উত্তর — প্রথম অংশ সাথে সাথে দেখা যায়",
                "📷 ছবি বিশ্লেষণ: OCR, গণিত, ডায়াগ্রাম, চার্ট, স্ক্রিনশট",
                "🌐 প্রয়োজনে web search ও সূত্র",
                "📚 বাংলা ও English, ধাপে ধাপে গণিত",
                "🕘 লোকাল চ্যাট ইতিহাস, সার্চ, রিনেম, ব্যাকআপ",
                "🌗 Light / Dark থিম",
            ).forEach { Text(it, fontSize = 14.sp) }
        }
        Section("Creator") { Text(CreatorQ.REPLY, fontSize = 14.sp) }
        Text("AI ভুল করতে পারে। গুরুত্বপূর্ণ তথ্য (স্বাস্থ্য, আইন, অর্থ) যাচাই করুন বা বিশেষজ্ঞের পরামর্শ নিন।",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}
