# Smart Education AI — Android অ্যাপ

Kotlin + Jetpack Compose। Streaming চ্যাট, ছবি বিশ্লেষণ, Markdown, লোকাল ইতিহাস, Light/Dark, Web search।
আপনার ছবিটি চ্যাট স্ক্রিনের ব্যাকগ্রাউন্ড (`res/drawable-nodpi/chat_bg.webp`, ১০৮০px, ~২৮KB) এবং তার ওপর হালকা overlay আছে।

## ধাপ ১ — ফ্রি Gemini API key
https://aistudio.google.com/apikey থেকে key নিন (ফ্রি টিয়ার)।

## ধাপ ২ — Worker deploy (key সুরক্ষিত থাকে, অ্যাপে থাকে না)
Node.js ইনস্টল থাকলে `worker/` ফোল্ডারে:
```
npx wrangler login
npx wrangler secret put GEMINI_API_KEY      # key পেস্ট করুন
npx wrangler deploy
```
শেষে একটি URL পাবেন: `https://smart-education-ai.<নাম>.workers.dev`
(ঐচ্ছিক: `npx wrangler secret put APP_TOKEN` দিয়ে একটি পাসওয়ার্ড দিন, তারপর অ্যাপে একই টোকেন দিন।)

## ধাপ ৩ — URL বসান
- হয় `app/src/main/java/com/smarteducation/ai/Config.kt`-এ `DEFAULT_WORKER_URL` দিন,
- নয়তো অ্যাপ চালিয়ে **সেটিংস → সার্ভার → Worker URL**-এ পেস্ট করুন (রিবিল্ড লাগবে না)।

## ধাপ ৪ — APK বানান
Android Studio (Koala বা নতুন) দিয়ে এই ফোল্ডার খুলুন → Gradle sync শেষ হলে:
**Build → Build Bundle(s) / APK(s) → Build APK(s)**
APK পাবেন: `app/build/outputs/apk/debug/app-debug.apk` — ফোনে কপি করে install করুন।
(Release APK: `./gradlew assembleRelease` → `app/build/outputs/apk/release/`; এটি debug key-তে sign করা, ব্যক্তিগত ব্যবহারের জন্য ঠিক আছে।)

## গতির জন্য যা করা আছে
- Gemini → Worker → অ্যাপ: SSE stream সরাসরি pass-through, কোনো buffering নেই
- Thinking বন্ধ (thinkingBudget = 0) ⇒ প্রথম token দ্রুত
- অ্যাপ খুলেই সার্ভারের সাথে connection আগে থেকে গরম (warm-up)
- Compression বন্ধ ⇒ stream আটকে থাকে না; UI আপডেট ~৪৫ms throttle ⇒ লম্বা উত্তরেও lag নেই
- ছবি পিক করার সময়ই ছোট করা হয় (সেটিংসে মান বাছা যায়), Send-এ কোনো দেরি নেই
- Web search শুধু "Auto" মোডে চলতি তথ্যের প্রশ্নে চলে
- Creator প্রশ্নের উত্তর নেটওয়ার্ক ছাড়াই তাৎক্ষণিক
- Busy হলে Worker নিজে থেকে হালকা মডেলে (flash-lite) fallback করে

## মনে রাখুন
- Gemini ফ্রি টিয়ারের rate limit আছে; বেশি ব্যবহারে 429 আসতে পারে।
- ফ্রি টিয়ারে পাঠানো ডেটা Google উন্নয়নের কাজে ব্যবহার করতে পারে — ব্যক্তিগত তথ্য পাঠাবেন না।
